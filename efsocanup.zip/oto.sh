#!/bin/bash
while :
do
/usr/bin/python3 /root/AutoRclone/autorclone.py
sleep 900
done
